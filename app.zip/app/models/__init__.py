# app/models/__init__.py

# Base
from .base import BaseModel
